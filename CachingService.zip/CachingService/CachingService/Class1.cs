﻿using System;

namespace CachingService
{
    public class Class1
    {

    }
}
