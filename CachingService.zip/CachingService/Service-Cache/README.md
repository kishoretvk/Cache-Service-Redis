# Service-Cache
class library to add to .net projects directly to give access to redis methods
