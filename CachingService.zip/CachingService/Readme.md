This is project to save time and keep simple methods to call a cache like Redis
we extrapolate existing methods and made it into a class library so everyone can easily use it.
feel free to  suggest me to impvoe this, 
this is a idea, it will udpated frequently . 


Thanks, 
tvk 